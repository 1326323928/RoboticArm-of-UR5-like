#include "uhs_config.h"
#include <BLEDevice.h>
//#include "hal/uhs_ble_master.h"
//#include "hal/uhs_posCompute_6500.h"
#include <BLEDevice.h>



uint8_t testdata[12] = {0xA1, 0xA1, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

static BLEAddress *pServerAddress;
bool deviceConnected = false;

// Client回调函数声明
class bleClientCallbacks : public BLEClientCallbacks
{
  void onConnect(BLEClient* pclient) {
    Serial.println("Connected to the BLE Server.");
  }

  void onDisconnect(BLEClient* pclient) {
    Serial.println("Disconnected from the BLE Server.");
  }
};



bool connectToServer(BLEAddress pAddress) {

  Serial.println("Start createClient!");

  BLEClient* pClient = BLEDevice::createClient();

  Serial.println("Start Connecting!");

  pClient->connect(pAddress);

  Serial.print("Conndeted to :");
  Serial.println(pAddress.toString().c_str());

  pClient->setClientCallbacks(new bleClientCallbacks());
  Serial.println(" - Connected to server");

  BLERemoteService* pRemoteService = pClient->getService(SERVICE_UUID);
  if (pRemoteService == nullptr) {
      Serial.println("Failed to find our service UUID.");
      return(false);
  }

  BLERemoteCharacteristic* flroCharacteristic = pRemoteService->getCharacteristic(CHARACTERISTIC_UUID);
  if (flroCharacteristic == nullptr) {
      Serial.println("Failed to find our characteristic UUID.");
      return(false);
  }
  return true;

}

class MyAdvertisedDeviceCallbacks: public BLEAdvertisedDeviceCallbacks {
    void onResult(BLEAdvertisedDevice advertisedDevice) {
        
        Serial.println("Device found: ");
        Serial.println(advertisedDevice.getAddress().toString().c_str());
        // 如果设备有名称，也打印出来
        if (advertisedDevice.haveName()) {
            Serial.print(" (");
            Serial.print(advertisedDevice.getName().c_str());
            Serial.println(")");
        }

        if (advertisedDevice.getName() == BLE_SERVICE_NAME) {
            BLEDevice::getScan()->stop();
            // 连接到服务端
            pServerAddress =  new BLEAddress(advertisedDevice.getAddress());
            connectToServer(*pServerAddress);
            deviceConnected = true;
        }
    }
};

void setup() 
{
  Serial.begin(115200);
  Serial.println("Serial Init Completed!");
    BLEDevice::init("BLE_MASTER_NAME");
    
    BLEScan* pBLEScan = BLEDevice::getScan();
    pBLEScan->setAdvertisedDeviceCallbacks(new MyAdvertisedDeviceCallbacks());
    
    pBLEScan->setActiveScan(true);
    pBLEScan->start(30,false);
}

void loop() 
{

}