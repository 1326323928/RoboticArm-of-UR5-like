#include "uhs_config.h"

extern HardwareSerial *pServoSerial;
void serial_UBT_Init(HardwareSerial* serial);
void ubtServo_Moveto(uint8_t id, uint8_t pos);









