#include "uhs_config.h"
#include <math.h>
extern bool isKine;
extern bool isHandle;
void ur5KineFun_ble_callback(uint8_t *data);
void ur5KineInit();
void clamp_run_by_handle_IMU(uint8_t *dataIMU);
void clamp_run_by_handle_AS5600(uint8_t *dataAS5600);







