#include "uhs_kine_3axis.h"
#include "ZDTStepper.h"
#include "uhs_UBTServo.h"
#include <PID_v1.h>
#include "uhs_demo.h"

#define MOTOR_NUM 5
#define SERVO_NUM 2
uint16_t defaultVel = 120;
uint16_t defaultAcc = 80;
uint16_t vel = defaultVel;
uint8_t acc = defaultAcc;
float stepPdeg = 266.6666667;

bool isMove = false;
bool isKine = false;
bool isHandle = false;

// 移动方向
int moveX = 0;
int moveY = 0;
int moveZ = 0;

// 关节旋转角度
float d[6] = {181, 203, 188, 73, 68.25, 50};

// 关节杆长
float theta[6] = {0, 0, 0, 0, 0, 0};

// 电机方向校正系数
static int8_t dir_coe[6] = {-1, -1, 1, -1, -1, -1};

// 夹爪位置修正系数
static int8_t clampPos_coe = 1;
float clampPos_offset[3] = {0, 0, 0};
bool isClampVertical = false;
// 偏摆修正系数
float pitch_offset = 0;

// 关节末端绝对坐标结构体
typedef struct
{
    float axis3_absX;
    float axis3_absY;
    float axis3_absZ;
    float axis4_absX;
    float axis4_absY;
    float axis4_absZ;
} ur_axispos_list;
ur_axispos_list axis_list;

// 关节位置方向信息
typedef struct
{
    float set_angle[MOTOR_NUM]; // 逆解的角度(目标角度)
    float current_angle[MOTOR_NUM];
    uint8_t dir[MOTOR_NUM]; // 控制电机的方向
    float pos[MOTOR_NUM];   // float步数,使用时转化uint32
    float cur_pos[MOTOR_NUM];
} ur_motor_list;
ur_motor_list ur_list;

// 舵机位置信息
//舵机1 俯仰 舵机2 夹持，舵机1俯仰零位122
uint8_t servoMax[SERVO_NUM] = {190, 135};
uint8_t servoMin[SERVO_NUM] = {40, 60};
typedef struct
{
    uint8_t set_angle[SERVO_NUM] = {120, 120};
    uint8_t current_angle[SERVO_NUM] = {120, 120};
    uint8_t moveState[SERVO_NUM];
} servoClamp_list;
servoClamp_list servo_list;

/////////////////////////////////线程运行任务//////////////////////////////
static void ur_motor_run()
{
    for (uint8_t index = 0; index < MOTOR_NUM; ++index)
    {
        ur_list.pos[index] = ur_list.set_angle[index] * stepPdeg;
        if (ur_list.cur_pos[index] != ur_list.pos[index])
        {
            ur_list.dir[index] = ur_list.pos[index] < 0 ? 0 : 1;
            ur_list.dir[index] = dir_coe[index] == 1 ? ur_list.dir[index] : (!ur_list.dir[index]);
            uint32_t pos = (uint32_t)abs(ur_list.pos[index]);
            Emm_V5_Pos_Control(index + 1, ur_list.dir[index], vel, acc, pos, 1, 0);
            // Serial.printf("轴%d| 方向:%d| 位置:%5d  ||  ", index + 1, ur_list.dir[index], (uint32_t)ur_list.pos[index]);
            ur_list.cur_pos[index] = ur_list.pos[index];
            vTaskDelay(5 / portTICK_PERIOD_MS);
        }
    }
    // Serial.println();
}

static void ur_motor_run_by_angle()
{
    for (uint8_t index = 0; index < MOTOR_NUM; ++index)
    {
        ur_list.set_angle[index] = theta[index];
    }
}

// 舵机运行函数
static void servoClamp_run()
{
    for (uint8_t index = 0; index < SERVO_NUM; ++index)
    {
        if (servo_list.current_angle[index] < servo_list.set_angle[index])
        {
            servo_list.current_angle[index]++;
            ubtServo_Moveto(index + 1, servo_list.current_angle[index]);
        }
        else if (servo_list.current_angle[index] > servo_list.set_angle[index])
        {
            servo_list.current_angle[index]--;
            ubtServo_Moveto(index + 1, servo_list.current_angle[index]);
        }
    };
}
// app控制夹爪
static void servoClamp_run_by_app()
{
    for (uint8_t index = 0; index < SERVO_NUM; ++index)
    {
        if (servo_list.moveState[index] == 1 & servo_list.set_angle[index] < servoMax[index])
        {
            servo_list.set_angle[index] ++;
            // Serial.printf("舵机 %d 位置, %d  ", index + 1, servo_list.set_angle[index]);
        }
        else if (servo_list.moveState[index] == 2 & servo_list.set_angle[index] > servoMin[index])
        {
            servo_list.set_angle[index] --;
            // Serial.printf("舵机 %d 位置, %d  ", index + 1, servo_list.set_angle[index]);
        }
    };
}
// 主手控制夹爪及第六轴
void clamp_run_by_handle_IMU(uint8_t *dataIMU)
{
    float yaw = degrees(byteToFloat(dataIMU + 8));
    float roll = -8.5 * degrees(byteToFloat(dataIMU + 12)) * dir_coe[5];
    uint8_t dir = roll < 0 ? 0 : 1;
    float yawservoangle = map(yaw, -82, 85, servoMax[0], servoMin[0]);
    servo_list.set_angle[0] = (uint32_t)yawservoangle;
    Emm_V5_Pos_Control(6, dir, vel, 0, (uint32_t)abs(roll), 1, 0);
    // Serial.printf("dir: %d  |||  roll: %d  ", dir, (uint32_t)abs(roll));
    // Serial.println();
}
void clamp_run_by_handle_AS5600(uint8_t *dataAS5600)
{
    float clampAngle = degrees(byteToFloat(dataAS5600));
    float clampservoangle = map(clampAngle, 66, 110, servoMin[1], servoMax[1]);
    servo_list.set_angle[1] = (uint8_t)clampservoangle;
    Serial.printf("clampAngle: %d  |||  ", (uint8_t)clampAngle);
}
//////////////////////////////运动学角度函数/////////////////////////////////
static void inverse_kine_3axis(float x, float y, float z)
{
    theta[0] = -degrees(atan2(x, y));
    float alpha1 = degrees(atan2(z, sqrt(x * x + y * y)));
    float alpha2 = degrees(acos((d[1] * d[1] + z * z + x * x + y * y - d[2] * d[2]) / (2 * d[1] * sqrt(z * z + x * x + y * y))));
    theta[1] = -(90 - alpha1 - alpha2);
    float alpha3 = 180 - degrees(acos((d[1] * d[1] + d[2] * d[2] - (x * x + y * y + z * z)) / (2 * d[1] * d[2])));
    theta[2] = 90 - alpha3;
    theta[3] = -1 * theta[1] - theta[2] + clampPos_offset[0];
    theta[4] = (-theta[0] + pitch_offset) * clampPos_coe + clampPos_offset[1];
}

bool check_angle(float theta1, float theta2, float theta3)
{
    if (theta1 < -170 || theta1 > 170)
    {
        // Serial.printf("theta[0] error %d , must in -170<a<170\n", theta[0]);
        return false;
    }

    if (theta2 < -120 || theta2 > 120)
    {
        // Serial.printf("theta[1] error %d , must in -120<b<120\n", theta[1]);
        return false;
    }

    if (theta3 < -120 || theta3 > 120)
    {
        // Serial.printf("theta[2] error %d , must in -120<c<120\n", theta[2]);
        return false;
    }
    return true;
}

static void kine_3axis_run()
{
    if (isMove == false)
    {
        return;
    }
    inverse_kine_3axis(axis_list.axis3_absX, axis_list.axis3_absY, axis_list.axis3_absZ);
    if (check_angle(theta[0], theta[1], theta[2]) == true)
    {
        // TODO run
        ur_motor_run_by_angle();
        isMove = false;
    }
}

static void kine_setZero()
{
    axis_list.axis3_absX = 0;
    axis_list.axis3_absY = d[2];
    axis_list.axis3_absZ = d[1];
    inverse_kine_3axis(axis_list.axis3_absX, axis_list.axis3_absY, axis_list.axis3_absZ);
    ur_motor_run_by_angle();
}
static void changeClamp_up()
{
    // 初始姿态为夹爪朝上
    clampPos_coe = 1;
    clampPos_offset[0] = 0;
    clampPos_offset[1] = 0;
    

    inverse_kine_3axis(axis_list.axis3_absX, axis_list.axis3_absY, axis_list.axis3_absZ);
    vel = 1000;
    acc = 200;
    ur_motor_run_by_angle();
    delay(500);
    vel = defaultVel;
    acc = defaultAcc;
}
static void changeClamp_vertical()
{
    clampPos_coe = 0;
    clampPos_offset[0] = -90;
    clampPos_offset[1] = 0;
    
    inverse_kine_3axis(axis_list.axis3_absX, axis_list.axis3_absY, axis_list.axis3_absZ);
    vel = 1000;
    acc = 200;
    ur_motor_run_by_angle();
    delay(500);
    vel = defaultVel;
    acc = defaultAcc;
}
static void changeClamp_down()
{
    // 5轴方向颠倒,仅影响逆解角度,不影响电机运行方向
    clampPos_coe = -1;
    // 4轴顺时针旋转180度
    clampPos_offset[0] = -180;
    // 5轴顺时针旋转180度
    clampPos_offset[1] = -180;
    
    inverse_kine_3axis(axis_list.axis3_absX, axis_list.axis3_absY, axis_list.axis3_absZ);
    vel = 1000;
    acc = 200;
    ur_motor_run_by_angle();
    delay(500);
    vel = defaultVel;
    acc = defaultAcc;
}

//////////////////////////////演示demo轨迹函数/////////////////////////////
void playDemo(float path[][7], int num_points)
{
    for (int i = 1; i < num_points; ++i)
    {
        inverse_kine_3axis(path[i][0], path[i][1], path[i][2]);

        theta[4] = (path[i][3] + pitch_offset) * clampPos_coe + clampPos_offset[1];
        ur_motor_run_by_angle();

        float roll = -8.5 * path[i][4] * dir_coe[5];
        uint8_t dir = roll < 0 ? 0 : 1;
        Emm_V5_Pos_Control(6, dir, 50, 100, (uint32_t)abs(roll), 1, 0);

        float clampAng = path[i][5];
        servo_list.set_angle[1] = (uint8_t)clampAng;

        delay(path[i][6]);
    }
    Emm_V5_Pos_Control(6, 0, 50, 100, 0, 1, 0);
    delay(1500);
    servo_list.set_angle[0] = 60;
    delay(500);
    servo_list.set_angle[0] = 140;
    delay(500);
    servo_list.set_angle[0] = 60;
    delay(500);
    servo_list.set_angle[0] = 122;
    delay(1500);
    theta[4] = 0;
    kine_setZero();
}

/////////////////////////////////////蓝牙回调函数/////////////////////////////////////
void ur5KineFun_ble_callback(uint8_t *data)
{
    switch (data[0])
    {
    case 1:
    {
        isMove = true;
        switch (data[1])
        {
        case 1:
            axis_list.axis3_absX += data[2];
            break;
        case 2:
            axis_list.axis3_absX -= data[2];
            break;
        case 3:
            axis_list.axis3_absY += data[2];
            break;
        case 4:
            axis_list.axis3_absY -= data[2];
            break;
        case 5:
            axis_list.axis3_absZ += data[2];
            break;
        case 6:
            axis_list.axis3_absZ -= data[2];
            break;
        }
        break;
    }
    case 2:
    {
        switch (data[6])
        {
        case 1:
        {
            kine_setZero();
            break;
        }
        case 2:
            changeClamp_up();
            break;
        case 3:
            changeClamp_vertical();
            break;
        case 4:
            changeClamp_down();
            break;
        case 5:
        {
            pitch_offset = byteToFloat(data + 2);
            isMove = true;
        }
        break;
        }
        break;
    }
    case 3:
        servo_list.moveState[1] = data[5];

        break;
    case 8:
    {
        if (data[1] = 1)
        {
            int num_points = sizeof(demo1_path) / sizeof(demo1_path[0]);
            // 运行 playDemo 函数
            playDemo(demo1_path, num_points);
        }

        break;
    }
    case 9:
    {
        isHandle = data[1];
        // Serial.println(data[1]);
        break;
    }
    case 10:
    {
        isKine = data[1];
        // Serial.println(data[1]);
        break;
    }
    }
}

/////////////////////////////////////FreeRtos任务///////////////////////////////////
void task_ur5KineRun(void *pvParameters)
{
    while (1)
    {
        if (isKine)
        {
            kine_3axis_run();
            ur_motor_run();
        }
        vTaskDelay(15 / portTICK_PERIOD_MS);
    }
}
void task_ur5ClampRun(void *pvParameters)
{
    while (1)
    {
        if (isKine)
        {
            if (!isHandle)
            {
                servoClamp_run_by_app();
            }
            servoClamp_run();
        }
        vTaskDelay(3 / portTICK_PERIOD_MS);
    }
}

/////////////////////////////////初始化/////////////////////////////////////
void ur5KineInit()
{
    kine_setZero();
    xTaskCreatePinnedToCore(task_ur5KineRun, "ur5Kine", 4096, NULL, 1, NULL, 1);
    xTaskCreatePinnedToCore(task_ur5ClampRun, "ur5Clamp", 2048, NULL, 1, NULL, 1);
}