#include "uhs_UR5Ctrl.h"
#include "ZDTStepper.h"
#include "uhs_UBTServo.h"
#include "serialRec.h"

const int StepperTX_PIN = 19;
const int StepperRX_PIN = 22;

const int ServoTX_PIN = 23;
const int ServoRX_PIN = 18;

HardwareSerial StepSerial(1);  // 使用第二个硬件串行端口
HardwareSerial ServoSerial(2); // 使用第三个硬件串行端口

int32_t moPos[6];
// 电机方向校正系数
static int8_t dir_coe[7] = {0, -1, -1, 1, -1, -1, -1};
/**
 * [0] 0x01  电机ID: 1
 * [1] 0x00  控制模式:  0-停止 1-位置 2-速度 8-位置置零 9-失能 10-使能
 * [2] 0x00  位置: 方向 0-cw 1-ccw                             速度: 方向 0-cw 1-ccw
 * [3] 0x00        加速度 0-255, 0是直接启动                         加速度 0-255, 0是直接启动
 * [4] 0x00
 * [5] 0x00        速度(int16_t)                                    速度(int16_t)
 * [6] 0x00        相位/绝对标志，0为相对运动，1为绝对值运动
 * [7] 0x00
 * [8] 0x00
 * [9] 0x00
 * [10] 0x00        位置(int32_t)
 */

void ur5SingleAxis_ble_callback(uint8_t *data)
{
    uint8_t id = data[0];
    uint8_t dir = dir_coe[id] == 1 ? data[2] : (!data[2]);
    // uint8_t dir = data[2];
    uint8_t acc = data[3];
    uint16_t vel = byteToInt16(data + 4);
    // for (uint8_t i = 0; i < 10; i++)
    // {
    //     Serial.print(data[i]);
    //     Serial.print(" | ");
    // }
    // Serial.println();
    // switch 模式
    switch (data[1])
    {
    case 0:
    {
        Emm_V5_Stop_Now(id, false);
        break;
    }
    case 1:
    {
        uint32_t pos = byteToInt32(data + 7);
        // 相对位置
        if (data[6] == 0)
        {
            Emm_V5_Pos_Control(id, dir, vel, acc, pos, 0, 0);
        }
        // 绝对位置
        else if (data[6] == 1)
        {
            Emm_V5_Pos_Control(id, dir, vel, acc, pos, 1, 0);
        }
        break;
    }
    case 2:
    {
        Emm_V5_Vel_Control(id, dir, vel, acc, false);
        break;
    }
    case 8:
    {
        Emm_V5_Reset_CurPos_To_Zero(id);
        break;
    }
    case 9:
    {
        Emm_V5_En_Control(id, false, false);
        break;
    }
    case 10:
    {
        Emm_V5_En_Control(id, true, false);
        break;
    }
    default:
        break;
    }
}

void UR5_Init()
{
    serial_ZDT_Init(&StepSerial);
    StepSerial.begin(115200, SERIAL_8N1, StepperRX_PIN, StepperTX_PIN);
    serial_UBT_Init(&ServoSerial);
    serial_Rec_Init(&ServoSerial);
    ServoSerial.begin(115200, SERIAL_8N1, ServoRX_PIN, ServoTX_PIN);
    Serial.println("StepSerial Starting ~ ~ ~");
    // 等待串口初始化完成
    while (!StepSerial)
    {
        Serial.println("StepSerial Starting Failed!");
    }
    Serial.println("StepSerial Started!!!");
    // 上电延时2秒等待Emm_V5.0闭环初始化完毕
    delay(2000);
}