#include "uhs_config.h"

#define MIN(a, b) ((a) < (b) ? (a) : (b))



int64_t byteToInt64(const uint8_t *data);
int32_t byteToInt32(const uint8_t *data);
int16_t byteToInt16(const uint8_t *data);

void int64ToByte(int64_t value, uint8_t *byteArray, uint8_t startIndex);
void int32ToByte(int32_t value, uint8_t *byteArray, uint8_t startIndex);
void int16ToByte(int16_t value, uint8_t *byteArray, uint8_t startIndex);

void floatToByte(float value, uint8_t *byteArray, uint8_t startIndex);
void doubleToByte(double value, uint8_t *byteArray, uint8_t startIndex);
float byteToFloat(const uint8_t *data);
double byteToDouble(const uint8_t *data);

float squareFloat(float n);
uint32_t squareInt32(uint32_t n);
float sgn(float num);





