#include "serialRec.h"

HardwareSerial *pRecSerial = nullptr;

const uint8_t length = 20;
uint8_t data[length];

void processReceivedData(uint8_t *data)
{
  // 处理接收到的数据
  if (data[0] == 0xA1 && data[1] == 0x01)
  {
    clamp_run_by_handle_IMU(data + 3);
    // float yaw = degrees(byteToFloat(data+3+8));
    // float roll = degrees(byteToFloat(data + 3+12));
    // float mappitch = map(yaw,-82,85,0,240);

    // Serial.printf("mapyaw: %f | roll: %f  |  ", mapyaw, roll);
    // Serial.println();
  }
  else if (data[0] == 0xA1 && data[1] == 0x02)
  {
    clamp_run_by_handle_AS5600(data + 3);
    float clampAngle = degrees(byteToFloat(data + 3));
  }
}

void task_serialRecData(void *pvParameters)
{
  while (1)
  {
    if (isHandle)
    {
      if (pRecSerial->available())
      {
        size_t len = pRecSerial->readBytes(data, length);
        // 检查数据长度
        if (len == length)
        {
          processReceivedData(data);
        }
        else
        {
          // 如果数据长度不匹配，可能需要重新接收或者丢弃
          Serial.println("Data length mismatch, discarding data.");
        }
      }
    }
    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

void serial_Rec_Init(HardwareSerial *serial)
{
  pRecSerial = serial;
  xTaskCreate(task_serialRecData, "Serial Rec", 4096, NULL, 1, NULL);
}
