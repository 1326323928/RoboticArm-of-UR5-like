#ifndef _UHS_CONFIG_H_
#define _UHS_CONFIG_H_

#include <Arduino.h>
#include "hal/uhs_converter.h"

#define SERVICE_UUID "4fafc201-1fb5-459e-8fcc-c5c9c331914b" // 自定义蓝牙服务UUID

#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8" // 自定义蓝牙特征UUID

#define BLE_NAME "UR5"


struct dataPackage
{
    uint8_t *data;
    uint8_t size;
};
#endif