#include <Arduino.h>
#include "hal/uhs_UR5Ctrl.h"
#include "hal/uhs_ble.h"
#include "hal/uhs_kine_3axis.h"

void setup() 
{
  Serial.begin(115200);
  Serial.println("Serial Started !!!");
  UR5_Init();
  init_ble();
  ur5KineInit();
}

void loop() 
{
}

