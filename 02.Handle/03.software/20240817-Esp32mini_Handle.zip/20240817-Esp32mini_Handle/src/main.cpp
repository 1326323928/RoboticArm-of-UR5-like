#include "uhs_config.h"
#include "hal/uhs_posCompute.h"
#include "hal/serial_trans.h"


void setup() 
{
  
  Serial.begin(115200);
  delay(1000);
  handleInit();
  serialTrans_Init();
  delay(100);
}


void loop() 
{

}