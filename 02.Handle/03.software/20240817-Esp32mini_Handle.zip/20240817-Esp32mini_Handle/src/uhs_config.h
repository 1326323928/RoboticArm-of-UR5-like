#ifndef _UHS_CONFIG_H_
#define _UHS_CONFIG_H_

#include <Arduino.h>
#include "hal/uhs_converter.h"

#define SERVICE_UUID "4fafc201-1fb5-459e-8fcc-c5c9c331914b"         // 自定义蓝牙服务UUID

#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"  // 自定义蓝牙特征UUID

#define BLE_MASTER_NAME "IMU-Controller"
#define BLE_SERVICE_NAME "Flex-Robot"

const uint8_t roAddress[6] = { 0xA0, 0xA3, 0xB3, 0xAA, 0x21, 0xC2};

struct dataPackage
{
    uint8_t* data;
    uint8_t size;
};


#endif