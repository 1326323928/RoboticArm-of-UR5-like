#ifndef _SERIAL_TRANS_H_
#define _SERIAL_TRANS_H_
#include "uhs_config.h"
#include "uhs_posCompute.h"

void serialTrans_Init();











#endif