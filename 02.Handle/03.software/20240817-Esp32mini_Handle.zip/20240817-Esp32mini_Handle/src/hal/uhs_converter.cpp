#include "uhs_converter.h"

int64_t byteToInt64(const uint8_t *data)
{
  int64_t result = 0;
  for (int i = 0; i < 8; ++i)
  {
    result |= static_cast<int64_t>(data[i]) << (i * 8);
  }
  return result;
}

int32_t byteToInt32(const uint8_t *data)
{
  int64_t result = 0;
  for (int i = 0; i < 4; ++i)
  {
    result |= static_cast<int64_t>(data[i]) << (i * 8);
  }
  return result;
}

int16_t byteToInt16(const uint8_t *data)
{
  int64_t result = 0;
  for (int i = 0; i < 2; ++i)
  {
    result |= static_cast<int64_t>(data[i]) << (i * 8);
  }
  return result;
}

void int64ToByte(int64_t value, uint8_t *byteArray, uint8_t startIndex)
{
  for (uint8_t i = 0; i < 8; ++i)
  {
    byteArray[startIndex + i] = (uint8_t)(value >> (i * 8));
  }
}

void int32ToByte(int32_t value, uint8_t *byteArray, uint8_t startIndex)
{
  for (uint8_t i = 0; i < 4; ++i)
  {
    byteArray[startIndex + i] = (uint8_t)(value >> (i * 8));
  }
}

void int16ToByte(int16_t value, uint8_t *byteArray, uint8_t startIndex)
{
  for (uint8_t i = 0; i < 2; ++i)
  {
    byteArray[startIndex + i] = (uint8_t)(value >> (i * 8));
  }
}

///////////////////////////////////////////////////////////////////
void floatToByte(float value, uint8_t *byteArray, uint8_t startIndex)
{
  // 使用 reinterpret_cast 将 float 指针转换为 uint8_t 指针
  uint8_t *floatToBytes = reinterpret_cast<uint8_t *>(&value);

  // 将 float 的字节数据复制到目标数组的指定位置
  for (uint8_t i = 0; i < sizeof(float); ++i)
  {
    byteArray[startIndex + i] = floatToBytes[i];
  }
}

void doubleToByte(double value, uint8_t *byteArray, uint8_t startIndex)
{
  // 使用 reinterpret_cast 将 double 指针转换为 uint8_t 指针
  uint8_t *doubleToBytes = reinterpret_cast<uint8_t *>(&value);

  // 将 double 的字节数据复制到目标数组的指定位置
  for (uint8_t i = 0; i < sizeof(double); ++i)
  {
    byteArray[startIndex + i] = doubleToBytes[i];
  }
}

float byteToFloat(const uint8_t *data)
{
  // 将字节数组中的数据转换为 float 类型
  float value = *reinterpret_cast<const float *>(data);
  return value;
}

double byteToDouble(const uint8_t *data)
{
  // 将字节数组中的数据转换为 double 类型
  double value = *reinterpret_cast<const double *>(data);
  return value;
}

void floatArray2ByteArray(float floatArray[], uint8_t byteArray[], uint8_t startIndex, size_t floatArraySize)
{
    int offset = startIndex;
    for (int i = 0; i < floatArraySize; i++)
    {
        uint8_t *angleBytes = (uint8_t *)(void *)&floatArray[i];
        memcpy(byteArray + offset, angleBytes, sizeof(float));
        offset += sizeof(float);
    }
}

float mapValue_float(float x, float in_min, float in_max, float out_min, float out_max) {
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

int32_t mapValue_int32(int32_t x, int32_t in_min, int32_t in_max, int32_t out_min, int32_t out_max) {
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}