#include "uhs_posCompute.h"
#include <SimpleKalmanFilter.h>

#define SDA 1
#define SCL 2

#define PWM_PIN1 1
#define PWM_PIN2 2
#define PWM_PIN3 3

TwoWire Sens_I2C = TwoWire(0);

Sensor_MPU6500 Sens_MPU5600(&Sens_I2C);
Sensor_AS5600 Sens_AS5600(&Sens_I2C);

SimpleKalmanFilter kalmanX(0.1, 0.01, 0.01); // Kalman Filter for X axis
SimpleKalmanFilter kalmanY(0.1, 0.01, 0.01); // Kalman Filter for Y axis

///////////////////////////////////////////    IMU传感器相关     /////////////////////////////////////////////
// IMU数据,帧头 A1,帧ID 01,帧尾 FF数据位 16(2 * 4 bite位),
uint8_t byteArray_imuData[20] = {0xA1, 0x01, 16,
                                 00, 00, 00, 00,
                                 00, 00, 00, 00,
                                 00, 00, 00, 00,
                                 00, 00, 00, 00,
                                 0xFF};

float floatArray_imuData[4] = {0, 0, 0, 0};

float alpha = 0.3;                                    // 控制滤波器的实时性
float filteredX1 = 0, filteredY1 = 0, filteredZ1 = 0; // 第一次滤波的结果
float filteredX2 = 0, filteredY2 = 0, filteredZ2 = 0; // 第二次滤波的结果

dataPackage getImuData()
{
    Sens_MPU5600.Sensor_update();

    floatArray_imuData[0] = Sens_MPU5600.getRoll();
    floatArray_imuData[1] = Sens_MPU5600.getPitch();
    // 第一次滤波
    filteredX1 = alpha * floatArray_imuData[0] + (1 - alpha) * filteredX1;
    filteredY1 = alpha * floatArray_imuData[1] + (1 - alpha) * filteredY1;
    // 第二次滤波
    filteredX2 = alpha * filteredX1 + (1 - alpha) * filteredX2;
    filteredY2 = alpha * filteredY1 + (1 - alpha) * filteredY2;

    floatArray_imuData[2] = filteredX2;
    floatArray_imuData[3] = filteredY2;
    // 将浮点数组转为byte数组
    size_t floatArraySize = sizeof(floatArray_imuData) / sizeof(float);
    floatArray2ByteArray(floatArray_imuData, byteArray_imuData, 3, floatArraySize);
    dataPackage sendIMUData;
    sendIMUData.data = byteArray_imuData;
    sendIMUData.size = sizeof(byteArray_imuData);
    return sendIMUData;
}

///////////////////////////////////////////    AS560传感器相关     /////////////////////////////////////////////
// AS5600数据,帧头 A1,帧ID 02,帧尾 FF数据位 16(4  * 8 bite位),
uint8_t byteArray_as5600Data[20] = {0xA1, 0x02, 16,
                                    00, 00, 00, 00,
                                    00, 00, 00, 00,
                                    00, 00, 00, 00,
                                    00, 00, 00, 00,
                                    0xFF};

float floatArray_as5600Data[4] = {0, 0, 0, 0};

dataPackage getAS5600Data()
{
    Sens_AS5600.Sensor_update();
    floatArray_as5600Data[0] = Sens_AS5600.getAngle();
    // 将浮点数组转为byte数组
    size_t floatArraySize = sizeof(floatArray_as5600Data) / sizeof(float);
    floatArray2ByteArray(floatArray_as5600Data, byteArray_as5600Data, 3, floatArraySize);
    dataPackage sendAS5600Data;
    sendAS5600Data.data = byteArray_as5600Data;
    sendAS5600Data.size = sizeof(byteArray_as5600Data);
    return sendAS5600Data;
}

void handleInit()
{
    // pinMode(PWM_PIN1, INPUT);
    // pinMode(PWM_PIN2, INPUT);
    // pinMode(PWM_PIN3, INPUT_PULLUP);
    // 初始化i2c总线
    Sens_I2C.begin(SDA, SCL, 400000UL);
    // 初始化MPU6500
    Sens_MPU5600.Sensor_init();
    Serial.println("IMU加载完毕！");
    // Sens_AS5600.Sensor_init();
    // Serial.println("AS5600加载完毕！");
    delay(100);
}
