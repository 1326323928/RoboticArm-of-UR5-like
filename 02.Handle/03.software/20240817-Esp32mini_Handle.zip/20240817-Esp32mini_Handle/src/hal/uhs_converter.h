#include "uhs_config.h"

int64_t byteToInt64(const uint8_t *data);
int32_t byteToInt32(const uint8_t *data);
int16_t byteToInt16(const uint8_t *data);

void int64ToByte(int64_t value, uint8_t *byteArray, uint8_t startIndex);
void int32ToByte(int32_t value, uint8_t *byteArray, uint8_t startIndex);
void int16ToByte(int16_t value, uint8_t *byteArray, uint8_t startIndex);

void floatToByte(float value, uint8_t *byteArray, uint8_t startIndex);
void doubleToByte(double value, uint8_t *byteArray, uint8_t startIndex);
float byteToFloat(const uint8_t *data);
double byteToDouble(const uint8_t *data);

void floatArray2ByteArray(float floatArray[], uint8_t byteArray[], uint8_t startIndex, size_t floatArraySize);

float mapValue_float(float x, float in_min, float in_max, float out_min, float out_max);






