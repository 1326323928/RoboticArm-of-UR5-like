#include "uhs_config.h"
#include "Wire.h"
#include <MPU6500_WE.h>

#define MPU6500_ADDR 0x68

class Sensor_MPU6500
{
public:
    Sensor_MPU6500(TwoWire *w) : MPU6500(w, MPU6500_ADDR) {};
    void Sensor_init();
    void Sensor_update();
    float getYaw();
    float getPitch();
    float getRoll();
    float getDeviation();
    float getGX();
    float getGY();
    float getGZ();

private:
    //TwoWire *wire;
    MPU6500_WE MPU6500;
    xyzFloat gValue;
    xyzFloat angle;
    xyzFloat gyr;
    float temp;
    float resultantG;
};
