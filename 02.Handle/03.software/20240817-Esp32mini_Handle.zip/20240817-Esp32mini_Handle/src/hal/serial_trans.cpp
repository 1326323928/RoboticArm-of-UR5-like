#include "serial_trans.h"
#define TRANS_RX_PIN 10
#define TRANS_TX_PIN 9

HardwareSerial TransSerial(1);

void task_serialSendImuData(void *pvParameters)
{
    while (1)
    {
        dataPackage imuData = getImuData();
        TransSerial.write(imuData.data, imuData.size);
        vTaskDelay(30 / portTICK_PERIOD_MS);
    }
}

void task_serialSendAS5600Data(void *pvParameters)
{
    while (1)
    {
        dataPackage AS5600Data = getAS5600Data();
        TransSerial.write(AS5600Data.data, AS5600Data.size);
        vTaskDelay(30 / portTICK_PERIOD_MS);
    }
}

void serialTrans_Init()
{
    TransSerial.begin(115200, SERIAL_8N1, TRANS_RX_PIN, TRANS_TX_PIN);
    Serial.println("TransSerial Starting ~ ~ ~");
    while (!TransSerial)
    {
        Serial.println("TransSerial Starting Failed!");
    }
    Serial.println("TransSerial Started!!!");
    xTaskCreate(task_serialSendImuData, "Serial trans", 2048, NULL, 1, NULL);
    xTaskCreate(task_serialSendAS5600Data, "Serial trans AS5600", 1024, NULL, 1, NULL);
}
