#ifndef _UHS_POSCOMPUTE_6500_H_
#define _UHS_POSCOMPUTE_6500_H_
#include "uhs_MPU6500.h"
#include "uhs_AS5600.h"
#include <Wire.h>
#include <vector>
#include "uhs_config.h"

void handleInit();
dataPackage getAS5600Data();
dataPackage getImuData();


#endif